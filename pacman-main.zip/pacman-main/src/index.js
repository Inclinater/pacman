import main from './main.js'
import {tableRecordsF} from './TableRecords.js'
main()
tableRecordsF()